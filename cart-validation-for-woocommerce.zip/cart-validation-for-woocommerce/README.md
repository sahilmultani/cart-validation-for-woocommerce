# cart-validation-for-woocommerce
Restrict checkout based on products, categories, user roles, and many more. Create powerful conditional rules and prevent incompatible purchases with custom error messages.
