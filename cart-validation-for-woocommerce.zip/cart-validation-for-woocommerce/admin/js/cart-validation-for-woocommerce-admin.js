/**
 * Admin scripts for Cart Validation for WooCommerce
 *
 * @package Cart_Validation_For_WooCommerce
 * @since 1.0.0
 */

(function ($) {
	'use strict';

	$(function () {
		// Placeholder for future admin JS (e.g. rule builder, product/category selectors).
	});

})(jQuery);
