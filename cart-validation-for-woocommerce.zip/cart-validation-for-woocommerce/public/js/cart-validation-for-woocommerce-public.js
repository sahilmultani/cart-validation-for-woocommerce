/**
 * Public scripts for Cart Validation for WooCommerce
 *
 * @package Cart_Validation_For_WooCommerce
 * @since 1.0.0
 */

(function ($) {
	'use strict';

	$(function () {
		// Placeholder for any front-end cart validation feedback (e.g. highlight incompatible items).
	});

})(jQuery);
